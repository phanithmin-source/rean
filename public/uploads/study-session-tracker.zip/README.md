# Study Session Tracker (Java & Spring Boot)

A clean reference project for tracking daily learning sessions, software topics, and study milestones.

## Features
- RESTful endpoints for session logging and progress analytics
- In-memory / PostgreSQL database persistence
- Input validation and global error handling
- Integration tests with JUnit 5 and MockMvc

## Prerequisites
- Java 21+
- Maven 3.9+

## Running the Project
```bash
./mvnw spring-boot:run
```
