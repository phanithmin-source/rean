package dev.rean.tracker;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.time.Instant;

@RestController
@RequestMapping("/api/sessions")
public class SessionController {
    @GetMapping
    public List<StudySession> getAllSessions() {
        return List.of(
            new StudySession("1", "Modern Java Virtual Threads", "programming", 90, Instant.now()),
            new StudySession("2", "REST API Error Handling", "backend", 60, Instant.now())
        );
    }

    public record StudySession(String id, String topic, String category, int minutesSpent, Instant recordedAt) {}
}
